<div class="wrap-BENrueeg_RUE_plugins">

<div class="wrap-BENrueeg_RUE_plugins-sect1">
<div class="wrap BENrueeg_RUE_width right"><div class="postbox"><div class="inside">
<p id="BENrueeg_RUE_wrap_ttext"><span id="font"><?php $ntb = str_replace( '-', ' ', $this->ntb ); echo $ntb . '&nbsp;&nbsp;'; ?></span><span style="float:right;" id="font">V <?php echo $this->plug_last_v($this->ntb); ?></span></p>
<div style="clear: both;" class="plug" id="ntb"></div>
<p id="BENrueeg_RUE_wrap_ttext">
This plugin allow you to display the latest posts or latest comments in a bar with twenty five beautiful animations and effects... 
<br /><p style="text-align:right;padding-right:12px;"><a target="_blank" href="https://wordpress.org/plugins/<?php echo $this->ntb; ?>/"><?php _e( 'more details ...', 'restrict-usernames-emails-characters' ); ?></a></p>
</p>
</div></div></div>

<div class="wrap BENrueeg_RUE_width left"><div class="postbox"><div class="inside">
<p id="BENrueeg_RUE_wrap_ttext"><span id="font"><?php $mntb = str_replace( '-', ' ', $this->mntb ); echo $mntb . '&nbsp;&nbsp;'; ?></span><span style="float:right;" id="font">V <?php echo $this->plug_last_v($this->mntb); ?></span></p>
<div style="clear: both;" class="plug" id="mntb"></div>
<p id="BENrueeg_RUE_wrap_ttext">
This plugin allows you to edit and translate the names of the months ...
<br /><p style="text-align:right;padding-right:12px;"><a target="_blank" href="https://wordpress.org/plugins/<?php echo $this->mntb; ?>/"><?php _e( 'more details ...', 'restrict-usernames-emails-characters' ); ?></a></p>
</p>
</div></div></div>
</div>

</div>

